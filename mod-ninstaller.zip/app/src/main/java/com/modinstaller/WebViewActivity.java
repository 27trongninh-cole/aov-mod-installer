package com.modinstaller;

import android.app.DownloadManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;

public class WebViewActivity extends AppCompatActivity {

    public static final String EXTRA_URL = "extra_url";
    public static final String EXTRA_TITLE = "extra_title";
    public static final String DOWNLOAD_SUBFOLDER = "ModNinstaller";

    private WebView webView;
    private ProgressBar progressBar;
    private ValueCallback<Uri[]> fileChooserCallback;
    private boolean pendingFolderMultiple = false;
    private java.util.List<String[]> pendingFolderFiles = null;
    private int pendingFolderIndex = 0;

    private final ActivityResultLauncher<Uri> folderPickerLauncher =
        registerForActivityResult(new ActivityResultContracts.OpenDocumentTree(), treeUri -> {
            if (treeUri == null) {
                if (fileChooserCallback != null) {
                    fileChooserCallback.onReceiveValue(null);
                    fileChooserCallback = null;
                }
                return;
            }
            // Duyệt file PNG/ZIP bên trong thư mục đã chọn, gửi nội dung base64
            // ngược lại cho web qua JS — vì WebView <input> không tự đọc được
            // từ 1 cây thư mục (DocumentTree), phải tự đọc và giả lập chọn file.
            new Thread(() -> readFolderAndInjectToWeb(treeUri)).start();
        });

    private final ActivityResultLauncher<Intent> fileChooserLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (fileChooserCallback == null) return;

            Uri[] resultUris = null;
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                Intent data = result.getData();
                if (data.getClipData() != null) {
                    // Nhiều file được chọn cùng lúc
                    int count = data.getClipData().getItemCount();
                    resultUris = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        resultUris[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    // 1 file duy nhất
                    resultUris = new Uri[]{data.getData()};
                }
            }
            fileChooserCallback.onReceiveValue(resultUris);
            fileChooserCallback = null;
        });

    // JS được inject ngay khi trang load xong, chặn mọi <a download> hoặc
    // window.open trên blob: URL để đọc dữ liệu NGAY LÚC CÒN TỒN TẠI,
    // tránh trường hợp blob bị revoke trước khi Android kịp fetch lại.
    private static final String INTERCEPT_JS =
        "(function() {" +
        "  if (window.__androidBlobHooked) return;" +
        "  window.__androidBlobHooked = true;" +
        "  function handleBlobUrl(blobUrl, fileName) {" +
        "    fetch(blobUrl).then(function(res) { return res.blob(); })" +
        "      .then(function(blob) {" +
        "        var reader = new FileReader();" +
        "        reader.onloadend = function() {" +
        "          var base64 = reader.result.split(',')[1];" +
        "          AndroidBlobDownload.saveBlobFile(base64, fileName || ('mod_' + Date.now() + '.zip'));" +
        "        };" +
        "        reader.readAsDataURL(blob);" +
        "      })" +
        "      .catch(function(err) { AndroidBlobDownload.onError(err.toString()); });" +
        "  }" +
        // Bắt click vào <a> gắn trong DOM thật (trường hợp mapdes)
        "  document.addEventListener('click', function(e) {" +
        "    var el = e.target;" +
        "    while (el && el.tagName !== 'A') el = el.parentElement;" +
        "    if (el && el.href && el.href.indexOf('blob:') === 0) {" +
        "      e.preventDefault();" +
        "      var name = el.download || null;" +
        "      handleBlobUrl(el.href, name);" +
        "    }" +
        "  }, true);" +
        // Chặn window.open trên blob URL
        "  var originalOpen = window.open;" +
        "  window.open = function(url, name, specs) {" +
        "    if (url && url.indexOf('blob:') === 0) {" +
        "      handleBlobUrl(url, null);" +
        "      return null;" +
        "    }" +
        "    return originalOpen.call(window, url, name, specs);" +
        "  };" +
        // QUAN TRỌNG: override click() ngay tại nguồn của HTMLAnchorElement.
        // Một số web (vd BNK Studio) tạo thẻ <a> hoàn toàn trong bộ nhớ JS
        // (document.createElement('a')) rồi gọi .click() ngay mà KHÔNG gắn
        // vào DOM (không appendChild) — sự kiện click khi đó không bao giờ
        // 'nổi bọt' lên document nên listener ở trên không bắt được.
        // Override trực tiếp hàm click() để chặn được cả trường hợp này.
        "  var originalAnchorClick = HTMLAnchorElement.prototype.click;" +
        "  HTMLAnchorElement.prototype.click = function() {" +
        "    if (this.href && this.href.indexOf('blob:') === 0 && this.download) {" +
        "      handleBlobUrl(this.href, this.download);" +
        "      return;" +
        "    }" +
        "    return originalAnchorClick.call(this);" +
        "  };" +
        "})();";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);

        String url = getIntent().getStringExtra(EXTRA_URL);
        String title = getIntent().getStringExtra(EXTRA_TITLE);

        TextView tvTitle = findViewById(R.id.tv_webview_title);
        if (tvTitle != null && title != null) tvTitle.setText(title);

        Button btnBack = findViewById(R.id.btn_webview_back);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        Button btnRefresh = findViewById(R.id.btn_webview_refresh);
        if (btnRefresh != null) btnRefresh.setOnClickListener(v -> {
            if (webView != null) webView.reload();
        });

        progressBar = findViewById(R.id.webview_progress);
        webView = findViewById(R.id.webview);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.addJavascriptInterface(new BlobDownloadInterface(), "AndroidBlobDownload");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String pageUrl) {
                super.onPageFinished(view, pageUrl);
                if (progressBar != null) progressBar.setVisibility(View.GONE);
                // Inject ngay khi trang load xong để hook sẵn, tránh miss blob download
                view.evaluateJavascript(INTERCEPT_JS, null);
            }
        });

        // Bridge <input type="file"> của web sang file picker thật của Android
        // Dùng ACTION_OPEN_DOCUMENT thay vì createIntent() mặc định để tránh
        // Android tự động mở "Photo Picker" (giao diện Truy cập riêng tư gây phiền)
        // — ép luôn mở app Files thật sự cho cả chọn file lẫn nhiều file.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                              FileChooserParams fileChooserParams) {
                if (fileChooserCallback != null) {
                    fileChooserCallback.onReceiveValue(null);
                }
                fileChooserCallback = filePathCallback;

                boolean allowMultiple = fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE;
                String[] acceptTypes = fileChooserParams.getAcceptTypes();

                // folderInput (webkitdirectory) không set accept cụ thể (PNG/ZIP),
                // trong khi fileInput luôn có accept=".png,.zip" — dùng đặc điểm
                // này để phân biệt, vì Android không truyền thẳng thuộc tính
                // webkitdirectory qua FileChooserParams.
                boolean looksLikeFolderRequest = allowMultiple && hasNoUsefulAcceptTypes(acceptTypes);

                if (looksLikeFolderRequest) {
                    try {
                        pendingFolderMultiple = true;
                        folderPickerLauncher.launch(null);
                    } catch (Exception e) {
                        fileChooserCallback = null;
                        Toast.makeText(WebViewActivity.this,
                            "Không mở được trình chọn thư mục: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        return false;
                    }
                    return true;
                }

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, allowMultiple);

                // QUAN TRỌNG: setType phải luôn là "*/*" — bất kỳ MIME type nào
                // bắt đầu bằng "image/" (kể cả image/png cụ thể) sẽ khiến Android 13+
                // tự động ưu tiên Photo Picker thay vì mở Files app thật.
                // Lọc loại file cụ thể (PNG/ZIP) chỉ qua EXTRA_MIME_TYPES, không qua setType.
                intent.setType("*/*");

                java.util.List<String> mimeTypes = new java.util.ArrayList<>();
                if (acceptTypes != null) {
                    for (String t : acceptTypes) {
                        if (t == null || t.isEmpty()) continue;
                        if (t.equals(".png") || t.equals("image/png")) mimeTypes.add("image/png");
                        else if (t.equals(".zip") || t.contains("zip")) {
                            mimeTypes.add("application/zip");
                            mimeTypes.add("application/x-zip-compressed");
                        } else if (t.startsWith("image/")) mimeTypes.add(t);
                    }
                }
                if (!mimeTypes.isEmpty()) {
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes.toArray(new String[0]));
                }

                try {
                    fileChooserLauncher.launch(intent);
                } catch (Exception e) {
                    fileChooserCallback = null;
                    Toast.makeText(WebViewActivity.this,
                        "Không mở được trình chọn file: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });

        // Fallback: vẫn giữ DownloadListener cho các link tải HTTP thường
        webView.setDownloadListener((downloadUrl, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (!downloadUrl.startsWith("blob:")) {
                downloadNormalFile(downloadUrl, userAgent, contentDisposition, mimeType);
            }
            // blob: URL đã được INTERCEPT_JS xử lý trước khi tới đây, bỏ qua
        });

        if (url != null) {
            webView.loadUrl(url);
        }
    }

    private void downloadNormalFile(String downloadUrl, String userAgent, String contentDisposition, String mimeType) {
        try {
            String fileName = android.webkit.URLUtil.guessFileName(downloadUrl, contentDisposition, mimeType);

            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));
            request.setMimeType(mimeType);
            request.addRequestHeader("User-Agent", userAgent);
            request.setDescription("Đang tải mod từ Mod Ninstaller");
            request.setTitle(fileName);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS, DOWNLOAD_SUBFOLDER + "/" + fileName);

            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (dm != null) {
                dm.enqueue(request);
                Toast.makeText(this, "Đang tải: " + fileName, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Lỗi tải file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // folderInput (webkitdirectory) không set accept cụ thể — dùng đặc điểm
    // này để phân biệt với fileInput (luôn có accept=".png,.zip")
    private boolean hasNoUsefulAcceptTypes(String[] acceptTypes) {
        if (acceptTypes == null || acceptTypes.length == 0) return true;
        for (String t : acceptTypes) {
            if (t != null && !t.isEmpty() && !t.equals("*/*")) return false;
        }
        return true;
    }

    // Đọc toàn bộ file PNG/ZIP trong thư mục đã chọn (DocumentTree), convert
    // sang base64, rồi gửi từng file cho JS dựng lại thành đối tượng File
    // thật trong trình duyệt, sau đó gọi thẳng handleFiles() có sẵn của web.
    private void readFolderAndInjectToWeb(Uri treeUri) {
        java.util.List<String[]> filesData = new java.util.ArrayList<>(); // [name, base64, mimeType]
        try {
            androidx.documentfile.provider.DocumentFile dir =
                androidx.documentfile.provider.DocumentFile.fromTreeUri(this, treeUri);
            if (dir != null && dir.isDirectory()) {
                for (androidx.documentfile.provider.DocumentFile child : dir.listFiles()) {
                    if (!child.isFile()) continue;
                    String name = child.getName();
                    if (name == null) continue;
                    String lower = name.toLowerCase();
                    if (!lower.endsWith(".png") && !lower.endsWith(".zip")) continue;

                    try (java.io.InputStream is = getContentResolver().openInputStream(child.getUri())) {
                        if (is == null) continue;
                        java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                        byte[] chunk = new byte[8192];
                        int len;
                        while ((len = is.read(chunk)) != -1) buffer.write(chunk, 0, len);
                        String base64 = Base64.encodeToString(buffer.toByteArray(), Base64.NO_WRAP);
                        String mime = lower.endsWith(".png") ? "image/png" : "application/zip";
                        filesData.add(new String[]{name, base64, mime});
                    } catch (Exception ignored) {
                    }
                }
            }
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this,
                "Lỗi đọc thư mục: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }

        // Báo cho callback gốc của WebView biết là "không có file nào" qua
        // đường input chuẩn — vì ta sẽ tự bơm file vào JS bằng cách khác.
        runOnUiThread(() -> {
            if (fileChooserCallback != null) {
                fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = null;
            }
            injectFolderFilesToWeb(filesData);
        });
    }

    private void injectFolderFilesToWeb(java.util.List<String[]> filesData) {
        if (filesData.isEmpty()) {
            Toast.makeText(this, "Thư mục không có file PNG/ZIP hợp lệ", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "Đang nạp " + filesData.size() + " file từ thư mục...", Toast.LENGTH_SHORT).show();

        // Khởi tạo mảng chứa file tạm ở phía JS trước khi gửi từng file một
        webView.evaluateJavascript("window.__androidFolderFiles = [];", null);

        // Gửi TỪNG file một qua JS riêng lẻ (thay vì gộp base64 của tất cả
        // file vào 1 câu JS khổng lồ) để tránh OutOfMemory / crash WebView
        // khi thư mục có nhiều ảnh.
        sendFilesSequentially(filesData, 0);
    }

    private void sendFilesSequentially(java.util.List<String[]> filesData, int index) {
        if (index >= filesData.size()) {
            // Đã gửi xong toàn bộ file → gọi handleFiles() 1 lần duy nhất
            String finalJs =
                "(function() {" +
                "  if (typeof handleFiles === 'function' && window.__androidFolderFiles) {" +
                "    var dt = new DataTransfer();" +
                "    window.__androidFolderFiles.forEach(function(f) { dt.items.add(f); });" +
                "    handleFiles(dt.files);" +
                "    window.__androidFolderFiles = [];" +
                "  }" +
                "})();";
            webView.evaluateJavascript(finalJs, null);
            pendingFolderFiles = null;
            pendingFolderIndex = 0;
            return;
        }

        String[] f = filesData.get(index);
        String name = f[0].replace("\\", "\\\\").replace("'", "\\'");
        String base64 = f[1];
        String mime = f[2];

        String js =
            "fetch('data:" + mime + ";base64," + base64 + "')" +
            "  .then(function(res) { return res.blob(); })" +
            "  .then(function(blob) {" +
            "    var file = new File([blob], '" + name + "', { type: '" + mime + "' });" +
            "    window.__androidFolderFiles.push(file);" +
            "    AndroidBlobDownload.onFolderFileReady();" +
            "  })" +
            "  .catch(function(e) {" +
            "    console.error('Lỗi nạp file " + name + ":', e);" +
            "    AndroidBlobDownload.onFolderFileReady();" +
            "  });";

        // Đợi JS báo xong file này (qua interface) rồi mới gửi file tiếp theo,
        // tránh dồn quá nhiều Promise cùng lúc gây nghẽn bộ nhớ.
        pendingFolderFiles = filesData;
        pendingFolderIndex = index;
        webView.evaluateJavascript(js, null);
    }

    private class BlobDownloadInterface {
        @JavascriptInterface
        public void saveBlobFile(String base64Data, String suggestedName) {
            try {
                byte[] fileBytes = Base64.decode(base64Data, Base64.DEFAULT);

                File downloadDir = new File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    DOWNLOAD_SUBFOLDER);
                if (!downloadDir.exists()) downloadDir.mkdirs();

                File outFile = new File(downloadDir, suggestedName);
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(fileBytes);
                }

                runOnUiThread(() -> Toast.makeText(WebViewActivity.this,
                    "Đã lưu: Download/" + DOWNLOAD_SUBFOLDER + "/" + suggestedName,
                    Toast.LENGTH_LONG).show());

            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(WebViewActivity.this,
                    "Lỗi lưu file: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void onError(String error) {
            runOnUiThread(() -> Toast.makeText(WebViewActivity.this,
                "Lỗi tải file: " + error, Toast.LENGTH_LONG).show());
        }

        // JS gọi lại khi 1 file trong thư mục đã được nạp xong (thành công
        // hoặc lỗi) — trigger gửi file tiếp theo trong hàng đợi tuần tự.
        @JavascriptInterface
        public void onFolderFileReady() {
            runOnUiThread(() -> {
                if (pendingFolderFiles == null) return;
                int nextIndex = pendingFolderIndex + 1;
                sendFilesSequentially(pendingFolderFiles, nextIndex);
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
